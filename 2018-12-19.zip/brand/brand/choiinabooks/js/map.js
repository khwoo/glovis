new Vue({

    el:".container",
    data: {
        brandName : '최인아책방'
    },
    filters:{



    },
    mounted: function() {

    }

});